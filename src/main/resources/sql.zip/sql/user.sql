INSERT INTO `user` VALUES ('1', 1, '1', 1);
